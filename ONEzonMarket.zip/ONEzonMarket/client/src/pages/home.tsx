import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ArrowRight, Shield, Truck, RotateCcw, Headphones } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Header from "@/components/header";
import Footer from "@/components/footer";
import ShoppingCart from "@/components/shopping-cart";
import ProductCard from "@/components/product-card";
import type { Category, ProductWithDetails, Seller } from "@shared/schema";

export default function Home() {
  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const { data: featuredProducts = [], isLoading: productsLoading } = useQuery<ProductWithDetails[]>({
    queryKey: ["/api/products/featured"],
  });

  const { data: sellers = [] } = useQuery<Seller[]>({
    queryKey: ["/api/sellers"],
  });

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <ShoppingCart />

      {/* Hero Section */}
      <section className="onezon-gradient text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-4">Welcome to ONEzon</h1>
            <p className="text-xl md:text-2xl mb-8 text-blue-100">Sudan's Premier Online Marketplace</p>
            <p className="text-lg mb-8 text-blue-200 max-w-2xl mx-auto">
              Discover millions of products from trusted sellers across Sudan. From electronics to traditional crafts, 
              find everything you need with secure payment and fast delivery.
            </p>
            <Link href="/products">
              <Button className="bg-white text-onezon-blue px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors">
                Start Shopping <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Trust Indicators */}
      <section className="bg-white py-8 border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div className="flex flex-col items-center">
              <Shield className="h-8 w-8 text-green-500 mb-2" />
              <span className="text-sm font-medium text-onezon-gray">Secure Shopping</span>
            </div>
            <div className="flex flex-col items-center">
              <Truck className="h-8 w-8 text-onezon-blue mb-2" />
              <span className="text-sm font-medium text-onezon-gray">Fast Delivery</span>
            </div>
            <div className="flex flex-col items-center">
              <RotateCcw className="h-8 w-8 text-orange-500 mb-2" />
              <span className="text-sm font-medium text-onezon-gray">Easy Returns</span>
            </div>
            <div className="flex flex-col items-center">
              <Headphones className="h-8 w-8 text-purple-500 mb-2" />
              <span className="text-sm font-medium text-onezon-gray">24/7 Support</span>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Categories */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-onezon-gray mb-8 text-center">Shop by Category</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {categories.slice(0, 4).map((category) => (
              <Link key={category.id} href={`/products?category=${category.id}`}>
                <Card className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow group cursor-pointer">
                  <CardContent className="p-6 text-center">
                    <img
                      src={category.imageUrl || ''}
                      alt={category.name}
                      className="w-full h-32 object-cover rounded-lg mb-4 group-hover:scale-105 transition-transform"
                    />
                    <h3 className="font-semibold text-onezon-gray mb-2">{category.name}</h3>
                    <p className="text-sm text-gray-600">{category.description}</p>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="bg-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold text-onezon-gray">Featured Products</h2>
            <Link href="/products">
              <Button variant="ghost" className="text-onezon-blue font-medium hover:text-onezon-dark-blue">
                View All <ArrowRight className="ml-1 h-4 w-4" />
              </Button>
            </Link>
          </div>

          {productsLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="bg-gray-200 rounded-xl animate-pulse h-80"></div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {featuredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Featured Sellers */}
      <section className="py-12 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-onezon-gray mb-8 text-center">Featured Sellers</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {sellers.map((seller) => (
              <Card key={seller.id} className="bg-white rounded-xl shadow-md">
                <CardContent className="p-6 text-center">
                  <img
                    src={seller.imageUrl || ''}
                    alt={seller.name}
                    className="w-20 h-20 rounded-full mx-auto mb-4 object-cover"
                  />
                  <h3 className="font-bold text-onezon-gray mb-2">{seller.name}</h3>
                  <div className="flex items-center justify-center mb-2">
                    <div className="flex text-yellow-400 mr-2">
                      {[...Array(5)].map((_, i) => (
                        <span key={i} className="text-sm">★</span>
                      ))}
                    </div>
                    <span className="text-sm text-gray-600">({seller.rating})</span>
                  </div>
                  <p className="text-sm text-gray-600 mb-4">{seller.description}</p>
                  {seller.isVerified && (
                    <span className="bg-green-100 text-green-600 px-3 py-1 rounded-full text-sm">
                      Verified Seller
                    </span>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
