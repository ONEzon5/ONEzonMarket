import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { ArrowLeft, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import Header from "@/components/header";
import Footer from "@/components/footer";
import ShoppingCart from "@/components/shopping-cart";
import { useCart } from "@/contexts/cart-context";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

const shippingSchema = z.object({
  fullName: z.string().min(2, "Full name is required"),
  phone: z.string().min(10, "Valid phone number is required"),
  state: z.string().min(1, "State is required"),
  city: z.string().min(2, "City is required"),
  address: z.string().min(10, "Detailed address is required"),
});

const checkoutSchema = z.object({
  shippingAddress: shippingSchema,
  paymentMethod: z.enum(["cod", "bank", "mobile"]),
});

type CheckoutFormData = z.infer<typeof checkoutSchema>;

export default function Checkout() {
  const [, setLocation] = useLocation();
  const { cartItems, cartTotal, clearCart } = useCart();
  const { toast } = useToast();

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
  } = useForm<CheckoutFormData>({
    resolver: zodResolver(checkoutSchema),
    defaultValues: {
      paymentMethod: "cod",
    },
  });

  const paymentMethod = watch("paymentMethod");

  const createOrderMutation = useMutation({
    mutationFn: async (data: CheckoutFormData) => {
      const orderData = {
        shippingAddress: data.shippingAddress,
        paymentMethod: data.paymentMethod,
        items: cartItems.map(item => ({
          productId: item.productId,
          quantity: item.quantity,
        })),
      };

      const res = await apiRequest("POST", "/api/orders", orderData);
      return res.json();
    },
    onSuccess: (order) => {
      toast({
        title: "Order placed successfully!",
        description: `Your order #${order.orderNumber} has been placed.`,
      });
      clearCart();
      setLocation("/orders");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to place order. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: CheckoutFormData) => {
    createOrderMutation.mutate(data);
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US').format(price);
  };

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <ShoppingCart />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Card className="text-center py-12">
            <CardContent>
              <h1 className="text-2xl font-bold text-gray-600 mb-4">Your cart is empty</h1>
              <p className="text-gray-500 mb-6">Add some products to your cart before checkout.</p>
              <Button onClick={() => setLocation("/products")} className="onezon-btn-primary">
                Continue Shopping
              </Button>
            </CardContent>
          </Card>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <ShoppingCart />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => setLocation("/products")}
            className="p-0 h-auto text-onezon-blue hover:text-onezon-dark-blue mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Continue Shopping
          </Button>
          <h1 className="text-3xl font-bold text-onezon-gray text-center">Checkout</h1>
        </div>

        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="grid md:grid-cols-2 gap-8">
            {/* Shipping Information */}
            <Card>
              <CardHeader>
                <CardTitle className="text-xl font-semibold">Shipping Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="fullName">Full Name *</Label>
                  <Input
                    id="fullName"
                    {...register("shippingAddress.fullName")}
                    className="mt-1"
                    placeholder="Ahmed Mohammed"
                  />
                  {errors.shippingAddress?.fullName && (
                    <p className="text-sm text-red-600 mt-1">
                      {errors.shippingAddress.fullName.message}
                    </p>
                  )}
                </div>

                <div>
                  <Label htmlFor="phone">Phone Number *</Label>
                  <Input
                    id="phone"
                    {...register("shippingAddress.phone")}
                    className="mt-1"
                    placeholder="+249 123 456 789"
                  />
                  {errors.shippingAddress?.phone && (
                    <p className="text-sm text-red-600 mt-1">
                      {errors.shippingAddress.phone.message}
                    </p>
                  )}
                </div>

                <div>
                  <Label htmlFor="state">State *</Label>
                  <Select onValueChange={(value) => setValue("shippingAddress.state", value)}>
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Select state" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="khartoum">Khartoum</SelectItem>
                      <SelectItem value="blue-nile">Blue Nile</SelectItem>
                      <SelectItem value="kassala">Kassala</SelectItem>
                      <SelectItem value="red-sea">Red Sea</SelectItem>
                      <SelectItem value="river-nile">River Nile</SelectItem>
                      <SelectItem value="north-kordofan">North Kordofan</SelectItem>
                      <SelectItem value="south-kordofan">South Kordofan</SelectItem>
                      <SelectItem value="white-nile">White Nile</SelectItem>
                      <SelectItem value="sennar">Sennar</SelectItem>
                      <SelectItem value="gedaref">Gedaref</SelectItem>
                    </SelectContent>
                  </Select>
                  {errors.shippingAddress?.state && (
                    <p className="text-sm text-red-600 mt-1">
                      {errors.shippingAddress.state.message}
                    </p>
                  )}
                </div>

                <div>
                  <Label htmlFor="city">City *</Label>
                  <Input
                    id="city"
                    {...register("shippingAddress.city")}
                    className="mt-1"
                    placeholder="Khartoum"
                  />
                  {errors.shippingAddress?.city && (
                    <p className="text-sm text-red-600 mt-1">
                      {errors.shippingAddress.city.message}
                    </p>
                  )}
                </div>

                <div>
                  <Label htmlFor="address">Detailed Address *</Label>
                  <Textarea
                    id="address"
                    {...register("shippingAddress.address")}
                    className="mt-1"
                    rows={3}
                    placeholder="Street, neighborhood, landmarks..."
                  />
                  {errors.shippingAddress?.address && (
                    <p className="text-sm text-red-600 mt-1">
                      {errors.shippingAddress.address.message}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Order Summary & Payment */}
            <div className="space-y-6">
              {/* Order Summary */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-xl font-semibold">Order Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {cartItems.map((item) => (
                      <div key={item.id} className="flex items-center space-x-3">
                        <img
                          src={item.product.imageUrl}
                          alt={item.product.name}
                          className="w-12 h-12 object-cover rounded"
                        />
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-sm truncate">{item.product.name}</p>
                          <p className="text-gray-600 text-sm">Qty: {item.quantity}</p>
                        </div>
                        <span className="font-bold text-onezon-blue">
                          SDG {formatPrice(parseFloat(item.product.price) * item.quantity)}
                        </span>
                      </div>
                    ))}
                  </div>

                  <div className="border-t pt-4 mt-6 space-y-2">
                    <div className="flex justify-between">
                      <span>Subtotal:</span>
                      <span>SDG {formatPrice(cartTotal)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Shipping:</span>
                      <span className="text-green-600">Free</span>
                    </div>
                    <div className="flex justify-between font-bold text-lg border-t pt-2">
                      <span>Total:</span>
                      <span className="text-onezon-blue">SDG {formatPrice(cartTotal)}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Payment Method */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-xl font-semibold">Payment Method</CardTitle>
                </CardHeader>
                <CardContent>
                  <RadioGroup
                    value={paymentMethod}
                    onValueChange={(value) => setValue("paymentMethod", value as "cod" | "bank" | "mobile")}
                    className="space-y-3"
                  >
                    <div className="flex items-center space-x-3">
                      <RadioGroupItem value="cod" id="cod" />
                      <Label htmlFor="cod" className="flex items-center cursor-pointer">
                        Cash on Delivery
                        <i className="fas fa-money-bill-wave text-green-500 ml-2"></i>
                      </Label>
                    </div>
                    <div className="flex items-center space-x-3">
                      <RadioGroupItem value="bank" id="bank" />
                      <Label htmlFor="bank" className="flex items-center cursor-pointer">
                        Bank Transfer
                        <i className="fas fa-university text-blue-500 ml-2"></i>
                      </Label>
                    </div>
                    <div className="flex items-center space-x-3">
                      <RadioGroupItem value="mobile" id="mobile" />
                      <Label htmlFor="mobile" className="flex items-center cursor-pointer">
                        Mobile Money
                        <i className="fas fa-mobile-alt text-purple-500 ml-2"></i>
                      </Label>
                    </div>
                  </RadioGroup>

                  <Button
                    type="submit"
                    disabled={createOrderMutation.isPending}
                    className="w-full onezon-btn-primary py-4 mt-6"
                  >
                    <Lock className="h-4 w-4 mr-2" />
                    {createOrderMutation.isPending ? "Placing Order..." : "Place Order Securely"}
                  </Button>

                  <p className="text-xs text-gray-500 text-center mt-3">
                    By placing your order, you agree to ONEzon's Terms of Service and Privacy Policy
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </form>
      </div>

      <Footer />
    </div>
  );
}
