import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Package, Search, Filter, Clock, Truck, CheckCircle, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import Header from "@/components/header";
import Footer from "@/components/footer";
import ShoppingCart from "@/components/shopping-cart";
import type { OrderWithItems } from "@shared/schema";

export default function Orders() {
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");

  const { data: orders = [], isLoading } = useQuery<OrderWithItems[]>({
    queryKey: ["/api/orders"],
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Search is handled client-side for simplicity
  };

  const filteredOrders = orders.filter(order => {
    const matchesSearch = searchQuery === "" || 
      order.orderNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.items.some(item => item.product.name.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesStatus = statusFilter === "all" || order.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const formatPrice = (price: string | number) => {
    return new Intl.NumberFormat('en-US').format(typeof price === 'string' ? parseFloat(price) : price);
  };

  const formatDate = (date: Date | string) => {
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    return dateObj.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "processing":
        return <Clock className="h-4 w-4" />;
      case "shipped":
        return <Truck className="h-4 w-4" />;
      case "delivered":
        return <CheckCircle className="h-4 w-4" />;
      case "cancelled":
        return <XCircle className="h-4 w-4" />;
      default:
        return <Package className="h-4 w-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "processing":
        return "bg-blue-100 text-blue-600";
      case "shipped":
        return "bg-orange-100 text-orange-600";
      case "delivered":
        return "bg-green-100 text-green-600";
      case "cancelled":
        return "bg-red-100 text-red-600";
      default:
        return "bg-gray-100 text-gray-600";
    }
  };

  const getStatusLabel = (status: string) => {
    return status.charAt(0).toUpperCase() + status.slice(1);
  };

  const getEstimatedDelivery = (createdAt: Date | string) => {
    const date = typeof createdAt === 'string' ? new Date(createdAt) : createdAt;
    const deliveryDate = new Date(date);
    deliveryDate.setDate(deliveryDate.getDate() + 3); // Add 3 days for estimated delivery
    
    return deliveryDate.toLocaleDateString('en-US', {
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <ShoppingCart />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-onezon-gray mb-6">My Orders</h1>
          
          <Card className="bg-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-6">
                <div className="flex space-x-4">
                  <Button
                    variant={statusFilter === "all" ? "default" : "outline"}
                    onClick={() => setStatusFilter("all")}
                    className={statusFilter === "all" ? "bg-onezon-blue text-white" : ""}
                  >
                    All Orders
                  </Button>
                  <Button
                    variant={statusFilter === "processing" ? "default" : "outline"}
                    onClick={() => setStatusFilter("processing")}
                    className={statusFilter === "processing" ? "bg-onezon-blue text-white" : ""}
                  >
                    Processing
                  </Button>
                  <Button
                    variant={statusFilter === "shipped" ? "default" : "outline"}
                    onClick={() => setStatusFilter("shipped")}
                    className={statusFilter === "shipped" ? "bg-onezon-blue text-white" : ""}
                  >
                    Shipped
                  </Button>
                  <Button
                    variant={statusFilter === "delivered" ? "default" : "outline"}
                    onClick={() => setStatusFilter("delivered")}
                    className={statusFilter === "delivered" ? "bg-onezon-blue text-white" : ""}
                  >
                    Delivered
                  </Button>
                </div>
                
                <div className="flex items-center space-x-2">
                  <form onSubmit={handleSearch} className="relative">
                    <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    <Input
                      type="text"
                      placeholder="Search orders..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10 pr-4 py-2 w-64"
                    />
                  </form>
                </div>
              </div>

              {/* Orders List */}
              {isLoading ? (
                <div className="space-y-4">
                  {[...Array(3)].map((_, i) => (
                    <Card key={i} className="border">
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between mb-4">
                          <div className="space-y-2">
                            <Skeleton className="h-4 w-48" />
                            <Skeleton className="h-3 w-32" />
                          </div>
                          <Skeleton className="h-6 w-20" />
                        </div>
                        <div className="flex items-center space-x-4">
                          <Skeleton className="w-16 h-16 rounded" />
                          <div className="flex-1 space-y-2">
                            <Skeleton className="h-4 w-40" />
                            <Skeleton className="h-3 w-32" />
                          </div>
                          <div className="text-right space-y-2">
                            <Skeleton className="h-4 w-24" />
                            <Skeleton className="h-3 w-20" />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : filteredOrders.length === 0 ? (
                <Card className="text-center py-12">
                  <CardHeader>
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Package className="h-8 w-8 text-gray-400" />
                    </div>
                    <CardTitle className="text-xl text-gray-600">
                      {orders.length === 0 ? "No orders yet" : "No orders found"}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-500 mb-6">
                      {orders.length === 0 
                        ? "Start shopping to see your orders here." 
                        : "Try adjusting your search or filter criteria."}
                    </p>
                    {orders.length === 0 && (
                      <Button 
                        onClick={() => window.location.href = "/products"}
                        className="onezon-btn-primary"
                      >
                        Start Shopping
                      </Button>
                    )}
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-4">
                  {filteredOrders.map((order) => (
                    <Card key={order.id} className="border hover:shadow-md transition-shadow">
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between mb-4">
                          <div>
                            <h3 className="font-semibold text-onezon-gray text-lg">
                              Order #{order.orderNumber}
                            </h3>
                            <p className="text-sm text-gray-600">
                              Placed on {formatDate(order.createdAt!)}
                            </p>
                          </div>
                          <Badge className={`${getStatusColor(order.status)} font-medium`}>
                            <div className="flex items-center space-x-1">
                              {getStatusIcon(order.status)}
                              <span>{getStatusLabel(order.status)}</span>
                            </div>
                          </Badge>
                        </div>
                        
                        <div className="flex items-center space-x-4">
                          <div className="flex -space-x-2">
                            {order.items.slice(0, 3).map((item, index) => (
                              <img
                                key={index}
                                src={item.product.imageUrl}
                                alt={item.product.name}
                                className="w-12 h-12 object-cover rounded-lg border-2 border-white"
                              />
                            ))}
                            {order.items.length > 3 && (
                              <div className="w-12 h-12 bg-gray-200 rounded-lg border-2 border-white flex items-center justify-center">
                                <span className="text-xs text-gray-600 font-medium">
                                  +{order.items.length - 3}
                                </span>
                              </div>
                            )}
                          </div>
                          
                          <div className="flex-1">
                            <h4 className="font-medium text-onezon-gray">
                              {order.items[0].product.name}
                              {order.items.length > 1 && ` + ${order.items.length - 1} other item${order.items.length > 2 ? 's' : ''}`}
                            </h4>
                            <p className="text-sm text-gray-600">
                              {order.status === "delivered" 
                                ? `Delivered on ${formatDate(order.createdAt!)}`
                                : order.status === "shipped"
                                ? `Estimated delivery: ${getEstimatedDelivery(order.createdAt!)}`
                                : `Estimated delivery: ${getEstimatedDelivery(order.createdAt!)}`
                              }
                            </p>
                          </div>
                          
                          <div className="text-right">
                            <p className="font-bold text-onezon-blue text-lg">
                              SDG {formatPrice(order.totalAmount)}
                            </p>
                            <Button 
                              variant="ghost"
                              size="sm"
                              className="text-onezon-blue hover:text-onezon-dark-blue mt-1"
                            >
                              {order.status === "delivered" ? "Review Products" : "Track Order"}
                            </Button>
                          </div>
                        </div>

                        {/* Order Items Summary */}
                        <div className="mt-4 pt-4 border-t border-gray-200">
                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
                            <div>
                              <span className="text-gray-600">Items: </span>
                              <span className="font-medium">{order.items.reduce((sum, item) => sum + item.quantity, 0)}</span>
                            </div>
                            <div>
                              <span className="text-gray-600">Payment: </span>
                              <span className="font-medium capitalize">
                                {order.paymentMethod === "cod" ? "Cash on Delivery" : 
                                 order.paymentMethod === "bank" ? "Bank Transfer" : "Mobile Money"}
                              </span>
                            </div>
                            <div className="sm:text-right">
                              <span className="text-gray-600">Delivery to: </span>
                              <span className="font-medium">
                                {order.shippingAddress.city}, {order.shippingAddress.state}
                              </span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      <Footer />
    </div>
  );
}
