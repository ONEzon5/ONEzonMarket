import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Search, User, Heart, ShoppingCart, Menu, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useCart } from "@/contexts/cart-context";
import { useQuery } from "@tanstack/react-query";
import type { Category } from "@shared/schema";

export default function Header() {
  const [location, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { setIsCartOpen, cartCount } = useCart();

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setLocation(`/products?search=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* ONEzon Logo */}
          <Link href="/" className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-onezon-blue rounded-full flex items-center justify-center">
              <div className="w-6 h-6 border-2 border-white rounded-full relative">
                <div className="absolute -left-1 -right-1 top-1/2 transform -translate-y-1/2 border border-white rounded-full"></div>
              </div>
            </div>
            <span className="text-2xl font-bold text-onezon-gray">ONEzon</span>
          </Link>

          {/* Search Bar - Hidden on mobile */}
          <div className="hidden md:flex flex-1 max-w-2xl mx-8">
            <form onSubmit={handleSearch} className="relative w-full">
              <Input
                type="text"
                placeholder="Search products, brands, categories..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-4 pr-12 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-onezon-blue focus:border-transparent"
              />
              <Button
                type="submit"
                className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-onezon-blue text-white px-4 py-1 rounded-md hover:bg-onezon-dark-blue transition-colors"
              >
                <Search className="h-4 w-4" />
              </Button>
            </form>
          </div>

          {/* User Actions */}
          <div className="flex items-center space-x-6">
            <Button
              variant="ghost"
              className="hidden sm:flex items-center space-x-1 text-onezon-gray hover:text-onezon-blue"
            >
              <User className="h-5 w-5" />
              <span>Account</span>
            </Button>
            
            <Button
              variant="ghost"
              className="hidden sm:flex items-center space-x-1 text-onezon-gray hover:text-onezon-blue"
            >
              <Heart className="h-5 w-5" />
              <span>Wishlist</span>
            </Button>
            
            <Button
              variant="ghost"
              onClick={() => setIsCartOpen(true)}
              className="flex items-center space-x-1 text-onezon-gray hover:text-onezon-blue relative"
            >
              <ShoppingCart className="h-5 w-5" />
              <span className="hidden sm:block">Cart</span>
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </Button>

            {/* Mobile menu button */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {/* Categories Navigation - Desktop */}
        <nav className="hidden md:block border-t border-gray-200 py-2">
          <div className="flex items-center space-x-8 text-sm">
            <Link
              href="/products"
              className="text-onezon-gray hover:text-onezon-blue font-medium"
            >
              All Categories
            </Link>
            {categories.slice(0, 7).map((category) => (
              <Link
                key={category.id}
                href={`/products?category=${category.id}`}
                className="text-onezon-gray hover:text-onezon-blue"
              >
                {category.name}
              </Link>
            ))}
          </div>
        </nav>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden border-t border-gray-200 py-4">
            {/* Mobile Search */}
            <form onSubmit={handleSearch} className="mb-4">
              <div className="relative">
                <Input
                  type="text"
                  placeholder="Search products..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-4 pr-12 py-2"
                />
                <Button
                  type="submit"
                  size="sm"
                  className="absolute right-2 top-1/2 transform -translate-y-1/2"
                >
                  <Search className="h-4 w-4" />
                </Button>
              </div>
            </form>

            {/* Mobile Navigation */}
            <div className="space-y-2">
              <Button
                variant="ghost"
                className="w-full justify-start"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                <User className="h-4 w-4 mr-2" />
                Account
              </Button>
              <Button
                variant="ghost"
                className="w-full justify-start"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                <Heart className="h-4 w-4 mr-2" />
                Wishlist
              </Button>
              <Link href="/orders">
                <Button
                  variant="ghost"
                  className="w-full justify-start"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  Orders
                </Button>
              </Link>
            </div>

            {/* Mobile Categories */}
            <div className="mt-4 pt-4 border-t border-gray-200">
              <h3 className="font-semibold text-onezon-gray mb-2">Categories</h3>
              <div className="space-y-2">
                <Link href="/products">
                  <Button
                    variant="ghost"
                    className="w-full justify-start text-sm"
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    All Categories
                  </Button>
                </Link>
                {categories.map((category) => (
                  <Link key={category.id} href={`/products?category=${category.id}`}>
                    <Button
                      variant="ghost"
                      className="w-full justify-start text-sm"
                      onClick={() => setIsMobileMenuOpen(false)}
                    >
                      {category.name}
                    </Button>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
