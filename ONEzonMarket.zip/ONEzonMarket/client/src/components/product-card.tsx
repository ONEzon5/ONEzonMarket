import { Link } from "wouter";
import { Star, ShoppingCart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useCart } from "@/contexts/cart-context";
import type { ProductWithDetails } from "@shared/schema";

interface ProductCardProps {
  product: ProductWithDetails;
}

export default function ProductCard({ product }: ProductCardProps) {
  const { addToCart } = useCart();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product.id, 1);
  };

  const formatPrice = (price: string) => {
    return new Intl.NumberFormat('en-US').format(parseFloat(price));
  };

  const renderStars = (rating: string) => {
    const ratingNum = parseFloat(rating);
    const fullStars = Math.floor(ratingNum);
    const hasHalfStar = ratingNum % 1 !== 0;
    
    return (
      <div className="flex text-yellow-400">
        {[...Array(fullStars)].map((_, i) => (
          <Star key={i} className="h-4 w-4 fill-current" />
        ))}
        {hasHalfStar && <Star className="h-4 w-4 fill-current opacity-50" />}
        {[...Array(5 - Math.ceil(ratingNum))].map((_, i) => (
          <Star key={`empty-${i}`} className="h-4 w-4" />
        ))}
      </div>
    );
  };

  return (
    <Link href={`/products/${product.id}`}>
      <Card className="bg-white border border-gray-200 rounded-xl hover:shadow-lg transition-shadow group cursor-pointer">
        <div className="relative overflow-hidden rounded-t-xl">
          <img
            src={product.imageUrl}
            alt={product.name}
            className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
          />
        </div>
        
        <CardContent className="p-4">
          <h3 className="font-semibold text-onezon-gray mb-2 line-clamp-2">
            {product.name}
          </h3>
          
          <div className="flex items-center mb-2">
            {renderStars(product.rating || "0")}
            <span className="text-sm text-gray-600 ml-2">
              ({product.rating}) {product.totalReviews} reviews
            </span>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex flex-col">
              <span className="text-lg font-bold text-onezon-blue">
                SDG {formatPrice(product.price)}
              </span>
              {product.originalPrice && (
                <span className="text-sm text-gray-500 line-through">
                  SDG {formatPrice(product.originalPrice)}
                </span>
              )}
            </div>
            
            <Button
              onClick={handleAddToCart}
              size="sm"
              className="bg-onezon-blue text-white hover:bg-onezon-dark-blue transition-colors"
            >
              <ShoppingCart className="h-4 w-4" />
            </Button>
          </div>
          
          {product.seller && (
            <div className="mt-3 pt-3 border-t border-gray-100">
              <p className="text-xs text-gray-600">
                Sold by <span className="font-medium">{product.seller.name}</span>
                {product.seller.isVerified && (
                  <span className="ml-1 text-green-600">✓</span>
                )}
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </Link>
  );
}
