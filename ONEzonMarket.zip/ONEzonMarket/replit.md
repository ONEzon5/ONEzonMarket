# ONEzon - Sudan's Premier E-commerce Platform

## Overview

ONEzon is a full-stack e-commerce marketplace designed specifically for Sudan's market. The platform connects buyers and sellers across the nation, offering a comprehensive online shopping experience similar to Amazon but tailored for local needs. The application features product browsing, shopping cart functionality, order management, and secure checkout processes with multiple payment options including cash on delivery, bank transfers, and mobile payments.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

The client-side is built as a modern React single-page application using:

- **React 18** with TypeScript for type safety and modern component patterns
- **Wouter** for lightweight client-side routing instead of React Router
- **TanStack Query (React Query)** for server state management, caching, and API synchronization
- **Tailwind CSS** with Shadcn/UI components for consistent, responsive design
- **Vite** as the build tool for fast development and optimized production builds

The frontend follows a page-based architecture with dedicated routes for home, products, product details, checkout, and orders. Components are organized into reusable UI elements using the Shadcn/UI design system with Radix UI primitives for accessibility.

### Backend Architecture

The server uses a Node.js/Express stack with:

- **Express.js** as the web framework with middleware for request logging and error handling
- **TypeScript** throughout for type safety across the full stack
- **RESTful API design** with endpoints for categories, products, sellers, cart management, and orders
- **Storage abstraction layer** that defines interfaces for all data operations, enabling easy database switching

The backend implements a clean separation between route handlers and business logic through the storage interface pattern.

### Data Storage

- **PostgreSQL** as the primary database with Neon Database as the cloud provider
- **Drizzle ORM** for type-safe database operations and schema management
- **Database schema** includes tables for users, categories, sellers, products, cart items, and orders with proper relationships
- **Schema validation** using Zod for runtime type checking and data validation

The schema supports complex e-commerce features including product ratings, seller verification, inventory tracking, and order management with multiple payment methods.

### State Management

- **React Context** for cart state management with persistent storage
- **TanStack Query** for server state caching and synchronization
- **Local storage** integration for cart persistence across browser sessions
- **Optimistic updates** for cart operations with proper error handling and rollback

### Authentication & Session Management

The application is structured to support user authentication with:
- User registration and login capabilities in the database schema
- Session-based authentication patterns prepared in the codebase
- Password hashing and secure user data storage design

## External Dependencies

### Database & Infrastructure
- **Neon Database** - Serverless PostgreSQL hosting with connection pooling
- **Drizzle Kit** - Database migration management and schema synchronization

### UI & Design System
- **Shadcn/UI** - Component library built on Radix UI primitives
- **Radix UI** - Unstyled, accessible components for complex UI patterns
- **Tailwind CSS** - Utility-first CSS framework with custom design tokens
- **Lucide React** - Icon library for consistent iconography
- **Inter Font** - Typography via Google Fonts

### Development & Build Tools
- **Vite** - Fast build tool with hot module replacement
- **TypeScript** - Type safety across the entire application
- **ESBuild** - Fast JavaScript bundler for production builds
- **PostCSS** - CSS processing with Tailwind CSS integration

### Form & Validation
- **React Hook Form** - Form state management with minimal re-renders
- **Zod** - Schema validation for forms and API data
- **Hookform Resolvers** - Integration between React Hook Form and Zod

### Payment & Checkout
The application supports multiple payment methods common in Sudan:
- Cash on Delivery (COD)
- Bank transfers
- Mobile money payments
- Structured for easy integration with local payment processors

### Utility Libraries
- **Class Variance Authority** - Utility for managing component variants
- **CLSX** - Conditional className utility
- **Date-fns** - Date manipulation and formatting
- **Nanoid** - Unique ID generation for various entities